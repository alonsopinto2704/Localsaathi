---
name: Local Utility Trust
colors:
  surface: '#f4faff'
  surface-dim: '#c8ddea'
  surface-bright: '#f4faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e8f6ff'
  surface-container: '#dcf1ff'
  surface-container-high: '#d6ebf9'
  surface-container-highest: '#d0e6f3'
  on-surface: '#091e27'
  on-surface-variant: '#3e4947'
  inverse-surface: '#1f333d'
  inverse-on-surface: '#e2f3ff'
  outline: '#6e7977'
  outline-variant: '#bdc9c6'
  surface-tint: '#006a63'
  primary: '#005c55'
  on-primary: '#ffffff'
  primary-container: '#0f766e'
  on-primary-container: '#a3faef'
  inverse-primary: '#80d5cb'
  secondary: '#7d5800'
  on-secondary: '#ffffff'
  secondary-container: '#fdbf47'
  on-secondary-container: '#704e00'
  tertiary: '#005c54'
  on-tertiary: '#ffffff'
  tertiary-container: '#00776d'
  on-tertiary-container: '#91fdef'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf2e8'
  primary-fixed-dim: '#80d5cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#ffdea9'
  secondary-fixed-dim: '#fabc45'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5f4100'
  tertiary-fixed: '#89f5e7'
  tertiary-fixed-dim: '#6bd8cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#f4faff'
  on-background: '#091e27'
  surface-variant: '#d0e6f3'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an unpretentious, trustworthy, and utilitarian mobile environment tailored for everyday local service discovery across Indian metropolitan and tier-2 contexts. The visual language balances civic dependability with modern Android utility, rejecting deceptive urgency patterns, hyperactive gamification, and synthetic ratings.

The design movement anchors in **Tactile Modernism combined with Functional Material Utility**:
- **Clarity over Decor:** Information architecture prioritizes direct access—provider locality, phone verification, and immediate communication channels.
- **Empathetic Legibility:** High contrast, deliberate optical weighting, and generous touch ergonomics (minimum 48dp target bounding boxes) ensure zero-friction operation in bright daylight, moving transit, and across varying device form factors.
- **Tone:** Grounded, calm, respectful, and dependable. Visual elements communicate institutional reliability without appearing bureaucratic.

## Colors

The palette leverages a stabilizing deep teal foundation paired with high-contrast text tones and restrained warm accents.

### Core Roles
- **Primary (`#0F766E`)**: Dominates critical actions, primary callouts, and key navigation states. Conveys stability and neighborhood reliability.
- **Primary Pressed / Hover (`#115E59`)**: Interactive active state for primary teal components.
- **Primary Tint (`#E6F4F2`)**: Surface wash for selected states, icon containers, and highlighted informational rows.
- **Warm Accent (`#F4B740`)**: Used sparingly for high-value focal moments (e.g., standout service categories or essential bookmarks).
- **Accent Muted (`#FEF3C7`)**: Low-contrast background pill for secondary contextual notes.

### Structural Neutrals
- **Background (`#F7F9FA`)**: Soft cool page backdrop that reduces eye strain in comparison to stark white.
- **Surface / Cards (`#FFFFFF`)**: Pure white layered elevations bounded by subtle structural strokes.
- **Border (`#E2E8F0`)**: Hairline architectural definition ensuring card separation on low-brightness displays.
- **Main Text (`#172B35`)**: Deep charcoal optimized for readability across high ambient light.
- **Secondary Text (`#52616B`)**: Cool slate gray dedicated to metadata, locations, and sub-labels.
- **Disabled / Muted (`#94A3B8`)**: Inactive states and decorative iconography.

### Semantic & Verification Badges
- **Verified Badge (`#0D9488`)**: Dedicated badge hue for verified phone records and identity checks.
- **Sponsored Tag (`#64748B`)**: Neutral slate outline badge preventing deceptive visual priority.
- **Success (`#16A34A`)**: Successful submissions and operational availability states.
- **Warning / Alert (`#D97706`)**: Non-destructive notices and operational caveats.
- **Error (`#DC2626`)**: Critical system failures, missing form inputs, and disconnected states.

## Typography

The type scale relies on clean, open-aperture sans-serif letterforms that harmonize with system Indic fallback fonts (such as Noto Sans Devanagari) to preserve vertical metrics across mixed-language localized strings.

- **Display & Section Headers:** `headline-lg` (24px bold) anchors primary landing viewports, while `headline-sm` to `headline-md` (18–20px semibold) commands provider titles and card section splits.
- **Reading Comfort:** `body-md` (15px) provides optical comfort for address lines, operational details, and reviews without crowding viewport density.
- **Badges and Action Labels:** `label-sm` (12px medium) and `label-md` (13px medium) structure verified chips, sponsored tags, and auxiliary metadata tags.

## Layout & Spacing

The layout is built upon an uncompromising **8dp spatial rhythm**:
- **Grid Architecture:** 4-column layout on compact mobile devices (320dp to 480dp width), extending to 8 columns on foldables and tablets. 
- **Canvas Margins:** Fixed `16px` (`margin`) outer edge gutters protect content against rounded screen corners and thumb reaches.
- **Touch-First Accessibility:** All interactive elements maintain a strict `48dp × 48dp` physical bounding box, irrespective of visual label size.
- **Stacking Spacing:** Spacing tokens (`space-xs: 4px`, `space-sm: 8px`, `space-md: 16px`, `space-lg: 24px`, `space-xl: 32px`) govern margins between distinct content groups and form fields.

## Elevation & Depth

Visual hierarchy employs low-intensity, diffuse ambient shadows coupled with explicit border outlines (`#E2E8F0`) to ensure contrast under varying screen backlights:

- **Level 0 (Flat Canvas):** Page surface (`#F7F9FA`) with zero elevation.
- **Level 1 (Cards, Category Tiles):** Background `#FFFFFF`, 1px solid `#E2E8F0`, shadow offset `0px 1px 3px rgba(23, 43, 53, 0.06)`, `0px 1px 2px rgba(23, 43, 53, 0.04)`.
- **Level 2 (Active Cards, Popovers, Modals):** Background `#FFFFFF`, 1px solid `#E2E8F0`, shadow offset `0px 4px 6px -1px rgba(23, 43, 53, 0.08)`, `0px 2px 4px -2px rgba(23, 43, 53, 0.05)`.
- **Level Fixed (Sticky Bottom Navigation & Action Bar):** Background `#FFFFFF`, border-top `1px solid #E2E8F0`, shadow `0px -3px 12px rgba(23, 43, 53, 0.05)`.

## Shapes

The design system adopts a balanced, friendly geometric radius:
- **Base Components (Cards, Panels):** 12px to 16px corner radius (`rounded-lg` token at `1rem / 16px`).
- **Interactive Buttons & Input Fields:** 12px corner radius for a sturdy, tactile appearance.
- **Chips, Badges, & Tags:** Fully pill-shaped (`9999px`) or `8px` depending on visual weight, delivering clean differentiation between content containers and metadata labels.

## Components

### Buttons
- **Primary Action (Call/Primary):** Solid `#0F766E`, `#FFFFFF` typography (`label-lg`), minimum height `48dp`, border-radius `12px`. Pressed state transitions to `#115E59`.
- **WhatsApp Action:** Specialized secondary filled button utilizing `#16A34A` background with crisp white typography, matching the 48dp minimum hit zone.
- **Secondary / Outline:** Background transparent, border `1.5px solid #0F766E`, text `#0F766E`, corner radius `12px`.

### Badges & Metadata Tags
- **Phone Verified Badge:** Background `#E6F4F2`, text `#0D9488`, radius `8px`, containing an explicit checkmark icon + "Phone Verified" text (`label-sm`).
- **Sponsored Tag:** Background transparent, border `1px solid #64748B`, text `#64748B` (`label-sm`), strictly non-deceptive.

### Provider Cards
- Crisp white surface (`#FFFFFF`) with `1px solid #E2E8F0` border and Level 1 ambient elevation.
- 16px corner radius.
- Padding `16px`.
- Structure: Header row (Provider Name, Distance in km, Verified Badge), middle row (Primary services offered as neutral pill tags, operating experience), footer row (Direct action CTA and locality description).

### Sticky Bottom Contact Bar
- Fixed to viewport footer with `Level Fixed` upward ambient shadow.
- Equal-width dual-button configuration: "Call Now" (Teal `#0F766E`) and "WhatsApp" (Green `#16A34A`), anchored by clear icon glyphs to accommodate quick action without scrolling.

### Category Tiles
- Square or 4:3 rounded tiles (`12px` radius), surface `#FFFFFF` with `1px solid #E2E8F0`.
- Dual-tone teal icon inside a circular `#E6F4F2` surface, accompanied by explicit single-line or double-line service titles in `#172B35` (`label-md`).

### Form Inputs & Filters
- Input containers maintain `48dp` vertical height, `#FFFFFF` fill, and `#E2E8F0` resting border.
- Active focus state: `2px solid #0F766E` with zero outer glow to eliminate visual noise.
- Floating helper and error texts rendered strictly in `#52616B` and `#DC2626` respectively.